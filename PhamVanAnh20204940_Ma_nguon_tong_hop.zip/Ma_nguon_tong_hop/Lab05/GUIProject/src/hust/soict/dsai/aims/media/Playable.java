package hust.soict.dsai.aims.media;

public interface Playable {
    public StringBuffer play() throws Exception;
}
