package hust.soict.dsai.aims.cart;

import hust.soict.dsai.aims.disc.DigitalVideoDisc;

public class Cart {
    public static final int MAX_NUMBERS_ORDERED = 20;
    private DigitalVideoDisc itemsOrdered[] = new DigitalVideoDisc[MAX_NUMBERS_ORDERED];
    int qtyOrdered = 0;

    public void addDigitalVideoDisc(DigitalVideoDisc disc) {
        if (qtyOrdered == MAX_NUMBERS_ORDERED) {
            System.out.println("The cart is almost full.");
        } else {

            itemsOrdered[qtyOrdered] = disc;
            qtyOrdered++;
            System.out.println("The disc " + "\"" + disc.getTitle() + "\" " + "has been added.");
        }
    }

    public void removeDigitalVideoDisc(DigitalVideoDisc disc){
        for(int i = 0; i < qtyOrdered; i++)
        {
            if(itemsOrdered[i].equals(disc))
            {
                if(i == MAX_NUMBERS_ORDERED - 1) qtyOrdered --;
                else {
                    for (int j = i + 1; j < qtyOrdered; j++) {
                        itemsOrdered[j - 1] = itemsOrdered[j];
                    }
                    qtyOrdered--;
                }
            }
        }
        System.out.println("The disc " + "\"" + disc.getTitle() +"\" "+" has been removed from the cart.");
    }

    public float totalCost(){
        float total = 0;
        for(int i = 0; i < qtyOrdered; i++)
        {
            total = total + itemsOrdered[i].getCost();
        }
        return total;
    }

    //2.1 Overloading by differing types of parameter
    public void addDigitalVideoDisc(DigitalVideoDisc []dvdList)
    {
        for(int i = 0; i < dvdList.length; i++)
        {
            addDigitalVideoDisc(dvdList[i]);
        }
    }

    //2.2 Overloading by differing types of parameter
    public void addDigitalVideoDisc(DigitalVideoDisc dvd1,DigitalVideoDisc dvd2){
        this.addDigitalVideoDisc(dvd1);
        this.addDigitalVideoDisc(dvd2);
    }

    public void printcart(){
        System.out.println("************************************CART************************************");

        if(qtyOrdered != 0){
            for(int i = 0; i < qtyOrdered; i++){
                System.out.println((i+1)+". DVD " + itemsOrdered[i].toString());
            }
        }
        else System.out.println("Cart is empty!");

        System.out.println("Total cost: " + totalCost());
        System.out.println("***************************************************************************");
    }

    public void search(String title)
    {
        boolean check = false;
        for(int i = 0; i < qtyOrdered; i++)
        {
            if(itemsOrdered[i].isMatch(title))
            {
                check = true;
                System.out.println(itemsOrdered[i].toString());
            }
        }
        if(check == false)
        {
            System.out.println("Not found.");
        }
    }

    public void search(int id){
        boolean check = false;
        for(int i = 0; i < qtyOrdered; i++)
        {
            if(itemsOrdered[i].isMatch(id))
            {
                check = true;
                System.out.println(itemsOrdered[i].toString());
            }
        }
        if(check == false)
        {
            System.out.println("Not found.");
        }
    }

}
