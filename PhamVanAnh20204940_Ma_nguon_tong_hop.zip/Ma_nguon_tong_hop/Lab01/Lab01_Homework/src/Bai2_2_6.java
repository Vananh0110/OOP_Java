import java.util.Scanner;
import java.lang.Math;

public class Bai2_2_6 {
    public static void phuongtrinhbacnhat(double a, double b) {
        if (a == 0 && b == 0) System.out.println("Phương trình có vô số nghiệm.");
        if (a == 0 && b != 0) System.out.println("Phương trình vô nghiệm");
        else {
            double x = -b / a;
            System.out.println("Nghiệm của phương trình là: x = " + x);
        }
    }

    public static void phuongtrinhbachai(double a, double b, double c) {
        if (a == 0) {
            phuongtrinhbacnhat(b, c);
        } else {
            double delta = b * b - 4 * a * c;
            if (delta < 0) System.out.println("Phương trình vô nghiệm.");
            else if (delta == 0) {
                double nkep = -b / (2 * a);
                System.out.println("Phương trình có nghiệm kép: x = " + nkep);
            } else {
                double x1, x2;
                x1 = (-b + Math.sqrt(delta)) / (2 * a);
                x2 = (-b - Math.sqrt(delta)) / (2 * a);
                System.out.println("Phương trình có 2 nghiệm phân biệt: x1 = " + x1 + ", x2 = " + x2);
            }
        }
    }

    public static void hephuongtrinh(double a1, double a2, double b1, double b2, double c1, double c2) {
        double D = a1 * b2 - a2 * b1;
        double Dx = c1 * b2 - c2 * b1;
        double Dy = a1 * c2 - a2 * c1;
        if (D == 0 && Dx == 0 && Dy == 0) System.out.println("Hệ phương trình có vô số nghiệm.");
        else if ((D == 0 && Dx != 0) || (D == 0 && Dy != 0)) System.out.println("Hệ phương trình vô nghiệm.");
        else System.out.println("x = " + Dx / D + ", y = " + Dy / D);
    }

    public static void Menu() {
        System.out.println("----------------MENU---------------");
        System.out.println("1, Phương trình bậc nhất.");
        System.out.println("2, Phương trình bậc hai.");
        System.out.println("3, Hệ phương trình.");
        System.out.println("4, Thoát. ");
        System.out.println("Mời bạn chọn chức năng: ");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean cont = true;
        do {
            Menu();
            int chon = sc.nextInt();
            switch (chon) {
                case 1:
                    System.out.println("Thực hiện chức năng 1:");
                    System.out.println("Nhập hệ số cho phương trình ax + b = 0");
                    System.out.print("Nhập a = ");
                    double a = sc.nextDouble();
                    System.out.print("Nhập b = ");
                    double b = sc.nextDouble();
                    phuongtrinhbacnhat(a, b);
                    break;
                case 2:
                    System.out.println("Thực hiện chức năng 2:");
                    System.out.println("Nhập hệ số cho phương trình ax^2 + bx + c = 0");
                    System.out.print("Nhập a = ");
                    double c = sc.nextDouble();
                    System.out.print("Nhập b = ");
                    double d = sc.nextDouble();
                    System.out.print("Nhập c = ");
                    double e = sc.nextDouble();
                    phuongtrinhbachai(c, d, e);
                    break;

                case 3:
                    System.out.println("Thực hiện chức năng 3:");
                    System.out.println("Nhập hệ số cho hệ phương trình a1*x + b1*y = c1; a2*x + b2*y =c2");
                    System.out.print("Nhập a1 = ");
                    double a1 = sc.nextDouble();
                    System.out.print("Nhập b1 = ");
                    double b1 = sc.nextDouble();
                    System.out.print("Nhập c1 = ");
                    double c1 = sc.nextDouble();
                    System.out.print("Nhập a2 = ");
                    double a2 = sc.nextDouble();
                    System.out.print("Nhập b2 = ");
                    double b2 = sc.nextDouble();
                    System.out.print("Nhập c2 = ");
                    double c2 = sc.nextDouble();
                    hephuongtrinh(a1, a2, b1, b2, c1, c2);
                    break;

                case 4:
                    System.out.println("Thoát chương trình.");
                    cont = false;
                    break;

                default:
                    System.out.println("Hãy chọn giá trị từ 1 đến 4.");
                    break;
            }
        } while (cont);
    }
}


