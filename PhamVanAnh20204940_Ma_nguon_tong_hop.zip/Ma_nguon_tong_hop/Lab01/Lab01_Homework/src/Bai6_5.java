import java.util.Scanner;

public class Bai6_5 {
    public static Scanner sc = new Scanner(System.in);

    public static void sortasc(int []array, int n)
    {
        for(int i = 0; i < n-1; i++)
        {
            for(int j = i+1; j < n; j++)
            {
                if(array[i] > array[j]){
                    int temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
    }

    public static void main(String[] args)
    {
        System.out.print("Nhập số phần tử của mảng: \nn = ");
        int n = sc.nextInt();

        int []arr = new int[n];
        int sum = 0;
        System.out.println("Nhập các phần tử của mảng:");
        for(int i = 0; i < n; i++)
        {
            System.out.printf("array[%d] = ", i);
            arr[i] = sc.nextInt();
            sum += arr[i];
        }

        sortasc(arr, n);
        System.out.println("Sắp xếp mảng theo thứ tự tăng dần: ");
        for(int i = 0; i < n; i++)
        {
            System.out.printf("%d ", arr[i]);
        }

        System.out.printf("\nTổng các giá trị của mảng là: %d\n", sum );
        System.out.printf("Giá trị trung bình của mảng là: %.2f", (float) sum/n);
    }
}
